/** Formulab App - Fixed Chat Display & All Sections Functional */
const CONFIG = { TG_TOKEN: "8777013495:AAHjxYnd-YTsteLM48m7_mF6w9xIaPqcgcI", TG_CHAT_ID: "-1003904291438", EJS_SERVICE_ID: "formulab_kevz", EJS_WELCOME_TEMPLATE: "template_6rio3od", EJS_RESET_TEMPLATE: "template_kd3j0vv", EJS_PUBLIC_KEY: "cmVzmtXmkUC8tV43-" };

window.onerror = function(msg, url, line) { console.error('⚠️ Error:', msg, 'Line:', line); return false; };

let emailjsReady = false, currentUser = null, sessionTimer, chatInterval;
window.currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    console.log("✅ DOM Loaded");
    try {
        if (typeof emailjs !== 'undefined') { emailjs.init(CONFIG.EJS_PUBLIC_KEY); emailjsReady = true; }
        const stored = localStorage.getItem('formulab_current_user');
        if (stored && stored !== 'null') {
            currentUser = JSON.parse(stored);
            window.currentUser = currentUser;
            if (currentUser) initApp(); else showAuth();
        } else { showAuth(); }
    } catch(e) { console.error('Init failed:', e); showAuth(); }
    
    ['mousemove','keydown','touchstart','click','scroll'].forEach(evt => window.addEventListener(evt, resetSessionTimer, { passive: true }));
    resetSessionTimer();
});

function resetSessionTimer() { 
    clearTimeout(sessionTimer); clearTimeout(chatInterval);
    if (currentUser) { 
        sessionTimer = setTimeout(() => { 
            localStorage.removeItem('formulab_current_user'); window.currentUser = null; 
            window.location.replace(window.location.pathname + '#session-expired'); 
        }, 30 * 60 * 1000); 
    } 
}

const apiCall = async (url, data = {}, method = 'POST') => {
    console.log(`🌐 ${method} ${url}`);
    try {
        const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: method === 'GET' ? null : JSON.stringify(data) });
        const json = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
        return method === 'DELETE' ? { success: true } : json;
    } catch (err) { console.error(`❌ ${url}:`, err.message); throw err; }
};

function showAuth() {
    document.getElementById('authScreen')?.classList.remove('hidden');
    document.getElementById('mainApp')?.classList.add('hidden');
    const fab = document.getElementById('messenger-fab'); if(fab) fab.style.display = 'none';
    const chat = document.getElementById('messenger-chat'); if(chat) chat.style.display = 'none';
}

function initApp() {
    console.log("🚀 App initialized for:", currentUser.name);
    document.getElementById('authScreen')?.classList.add('hidden');
    document.getElementById('mainApp')?.classList.remove('hidden');
    document.getElementById('userName').textContent = currentUser.name;
    document.getElementById('userAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
    document.getElementById('userRole').textContent = currentUser.position;
    
    initSidebar(); initModals(); initNav(); updateDateTime(); setInterval(updateDateTime, 1000);
    
    // ✅ Load all sections immediately
    setTimeout(() => {
        loadDashboardData();
        loadMaterials();
        loadFormulations();
        loadPRs();
        initMessengerChat();
    }, 200);
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    const toggle = document.getElementById('menuToggle');
    if (!sidebar || !toggle || !overlay) return;
    sidebar.classList.remove('open'); overlay.classList.remove('active');
    toggle.onclick = (e) => { e.stopPropagation(); sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
    overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
}

function initModals() {
    document.querySelectorAll('.btn-close, [data-close]').forEach(b => b.onclick = () => document.getElementById(b.dataset.close)?.classList.add('hidden'));
    document.querySelectorAll('.modal').forEach(m => m.onclick = (e) => { if(e.target===m) m.classList.add('hidden'); });
}

function initNav() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.onclick = () => {
            console.log("📍 Nav clicked:", item.dataset.page);
            document.querySelectorAll('.nav-item').forEach(x => x.classList.remove('active'));
            item.classList.add('active');
            const page = item.dataset.page;
            document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
            const target = document.getElementById(`page-${page}`);
            if(target) target.classList.remove('hidden');
            document.getElementById('pageTitle').textContent = item.querySelector('span').textContent;
            
            // ✅ Reload data for clicked section
            if(page === 'dashboard') loadDashboardData();
            if(page === 'materials') loadMaterials();
            if(page === 'formulations') loadFormulations();
            if(page === 'purchase') loadPRs();
            
            document.getElementById('sidebar').classList.remove('open');
            document.querySelector('.sidebar-overlay')?.classList.remove('active');
        };
    });
    const logoutBtn = document.getElementById('logoutBtn');
    if(logoutBtn) logoutBtn.onclick = () => { localStorage.removeItem('formulab_current_user'); window.location.reload(); };
}

function updateDateTime() { const el = document.getElementById('currentDateTime'); if(el) el.textContent = new Date().toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function showToast(m, t='info') { const e = document.getElementById('toast'); if(!e)return; e.textContent=m; e.className=`toast ${t}`; e.style.display='flex'; setTimeout(() => e.style.display='none', 3000); }
function loadDashboardData() { anime({ targets: '.stat-card', opacity: [0,1], translateY: [20,0], stagger: 100, duration: 500 }); }

document.getElementById('loginForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    try {
        const data = await apiCall('/api/login', { emailOrUser: document.getElementById('loginId').value.trim(), password: document.getElementById('loginPassword').value });
        currentUser = { ...data.user, role: 'user' }; window.currentUser = currentUser;
        localStorage.setItem('formulab_current_user', JSON.stringify(currentUser));
        showToast(`Welcome ${currentUser.name}!`, 'success'); initApp();
    } catch (err) { showToast('Login failed: ' + err.message, 'error'); }
});

document.getElementById('registerForm')?.addEventListener('submit', async e => {
    e.preventDefault(); e.stopImmediatePropagation();
    if(document.getElementById('regPassword').value !== document.getElementById('regConfirm').value) return showToast('Password mismatch', 'error');
    try {
        await apiCall('/api/register', { email: document.getElementById('regEmail').value, username: document.getElementById('regUsername').value, name: document.getElementById('regName').value, organization: document.getElementById('regOrganization').value, position: document.getElementById('regPosition').value, password: document.getElementById('regPassword').value });
        showToast('Account created!', 'success'); showAuth();
    } catch (err) { showToast('Failed: ' + err.message, 'error'); }
});

// ✅ INVENTORY
window.loadMaterials = async () => {
    console.log("📦 Loading materials...");
    const tb = document.getElementById('materialsBody'); if(!tb) return;
    try {
        const mats = await apiCall(`/api/materials?org=${encodeURIComponent(currentUser.organization)}`, {}, 'GET');
        console.log("✅ Materials loaded:", mats.length);
        tb.innerHTML = mats.length ? mats.map(m => {
            const low = m.stock <= m.min_stock;
            return `<tr><td><strong>${m.name}</strong></td><td>${m.category}</td><td>${m.unit}</td><td>₱${m.price}</td><td>${m.stock}</td><td><span class="badge ${low?'badge-danger':'badge-success'}">${low?'Low':'OK'}</span></td><td><button class="btn-icon" onclick="editMaterial(${m.id})"><i class="fas fa-pen"></i></button> <button class="btn-icon" onclick="deleteMaterial(${m.id})" style="color:red"><i class="fas fa-trash"></i></button></td></tr>`;
        }).join('') : '<tr><td colspan="7" style="text-align:center;padding:20px;color:#888">No materials found</td></tr>';
        document.getElementById('statMaterials').textContent = mats.length;
    } catch(e) { showToast('Failed to load materials', 'error'); }
};
document.getElementById('addMaterialBtn')?.addEventListener('click', () => {
    document.getElementById('materialForm').reset(); document.getElementById('matId').value = '';
    document.getElementById('materialModalTitle').textContent = 'Add Material';
    document.getElementById('materialModal').classList.remove('hidden');
});
document.getElementById('materialForm')?.addEventListener('submit', async e => {
    e.preventDefault(); const id = document.getElementById('matId').value;
    const data = { organization: currentUser.organization, name: document.getElementById('matName').value, category: document.getElementById('matCategory').value, unit: document.getElementById('matUnit').value, price: parseFloat(document.getElementById('matPrice').value)||0, stock: parseFloat(document.getElementById('matInventory').value)||0, min_stock: parseFloat(document.getElementById('matMinStock').value)||10, supplier: document.getElementById('matSupplier').value };
    try { await apiCall(id ? `/api/materials/${id}` : '/api/materials', data, id ? 'PUT' : 'POST'); showToast(id?'Updated':'Added','success'); document.getElementById('materialModal').classList.add('hidden'); loadMaterials(); } catch(e) { showToast('Failed', 'error'); }
});
window.editMaterial = async (id) => {
    try {
        const mats = await apiCall(`/api/materials?org=${encodeURIComponent(currentUser.organization)}`, {}, 'GET');
        const m = mats.find(x => x.id == id); if(!m) return;
        document.getElementById('matId').value = m.id; document.getElementById('matName').value = m.name;
        document.getElementById('matCategory').value = m.category; document.getElementById('matUnit').value = m.unit;
        document.getElementById('matPrice').value = m.price; document.getElementById('matInventory').value = m.stock;
        document.getElementById('matMinStock').value = m.min_stock; document.getElementById('matSupplier').value = m.supplier||'';
        document.getElementById('materialModalTitle').textContent = 'Edit Material'; document.getElementById('materialModal').classList.remove('hidden');
    } catch(e) { showToast('Load failed', 'error'); }
};
window.deleteMaterial = async (id) => {
    if(!confirm('Delete this material?')) return;
    try { await apiCall(`/api/materials/${id}`, {}, 'DELETE'); showToast('Deleted','success'); loadMaterials(); } catch(e) { showToast('Failed', 'error'); }
};

// ✅ FORMULATIONS
window.loadFormulations = () => {
    console.log("🧪 Loading formulations...");
    const list = JSON.parse(localStorage.getItem('formulab_formulations')||'[]');
    const c = document.getElementById('formulationsList'); if(!c) return;
    document.getElementById('statFormulations').textContent = list.length;
    console.log("✅ Formulations loaded:", list.length);
    c.innerHTML = list.length ? list.map((f, idx) => `
        <div class="formulation-card">
            <div class="form-header"><h4>${f.name}</h4><span class="badge badge-${f.status==='Approved'?'success':'warning'}">${f.status}</span></div>
            <p>Client: ${f.client} | Date: ${f.date}</p>
            <p style="font-weight:600; color:#0284c7;">Grand Total: ₱${(f.grandTotal||0).toFixed(2)}</p>
            <div class="form-actions" style="gap:8px; margin-top:10px;">
                <button class="btn btn-primary btn-sm" onclick="viewFormulation(${idx})">View</button>
                <button class="btn btn-secondary btn-sm" onclick="editFormulation(${idx})">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteFormulation(${idx})">Delete</button>
            </div>
        </div>`).join('') : '<p style="text-align:center;color:#888">No formulations saved</p>';
};
function getFormList() { return JSON.parse(localStorage.getItem('formulab_formulations')||'[]'); }
function saveFormList(list) { localStorage.setItem('formulab_formulations', JSON.stringify(list)); }
window.addFormRow = () => {
    const tbody = document.getElementById('formulationTableBody'); if(!tbody) return;
    tbody.insertAdjacentHTML('beforeend', `<tr><td><input class="form-input" style="width:100%;padding:6px;" placeholder="Raw Material"></td><td><input class="form-input" style="width:100%;padding:6px;" placeholder="Code"></td><td><input class="form-input" style="width:100%;padding:6px;" placeholder="Supplier"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="0" oninput="updateFormTotal()"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="1" oninput="updateFormTotal()"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="0" oninput="updateFormTotal()"></td><td><input class="form-total" readonly style="width:100%;padding:6px;background:#f1f5f9;" value="0.00"></td><td><button class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();updateFormTotal()"><i class="fas fa-trash"></i></button></td></tr>`);
};
window.updateFormTotal = () => {
    let ingTotal = 0;
    document.querySelectorAll('#formulationTableBody tr').forEach(tr => {
        const inputs = tr.querySelectorAll('input');
        const qty = parseFloat(inputs[3].value)||0; const batch = parseFloat(inputs[4].value)||1; const cost = parseFloat(inputs[5].value)||0;
        const total = (qty * batch * cost) / 1000; 
        tr.querySelector('.form-total').value = total.toFixed(2); ingTotal += total;
    });
    const utilities = parseFloat(document.getElementById('formUtilities').value)||0; 
    const packaging = parseFloat(document.getElementById('formPackaging').value)||0; 
    const labor = parseFloat(document.getElementById('formLabor').value)||0;
    const grand = ingTotal + utilities + packaging + labor;
    document.getElementById('footerIngredientsTotal').textContent = `₱${ingTotal.toFixed(2)}`;
    document.getElementById('footerGrandTotal').textContent = grand.toFixed(2);
    document.getElementById('footerMarkup').textContent = `₱${(grand*1.2).toFixed(2)}`;
    document.getElementById('footerMargin').textContent = `₱${(grand/0.8).toFixed(2)}`;
};
function populateForm(f, isView = false) {
    document.getElementById('formProductName').value = f.name;
    document.getElementById('formClient').value = f.client;
    document.getElementById('formDate').value = f.date;
    document.getElementById('formStatus').value = f.status;
    document.getElementById('formUtilities').value = f.utilities || 0;
    document.getElementById('formPackaging').value = f.packaging || 0;
    document.getElementById('formLabor').value = f.labor || 0;
    const tbody = document.getElementById('formulationTableBody'); tbody.innerHTML = '';
    (f.ingredients || []).forEach(ing => {
        tbody.insertAdjacentHTML('beforeend', `<tr><td><input class="form-input" style="width:100%;padding:6px;" value="${ing.name}"></td><td><input class="form-input" style="width:100%;padding:6px;" value="${ing.code}"></td><td><input class="form-input" style="width:100%;padding:6px;" value="${ing.supplier}"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="${ing.qty}" oninput="updateFormTotal()"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="${ing.batch}" oninput="updateFormTotal()"></td><td><input class="form-input" type="number" step="0.01" style="width:100%;padding:6px;" value="${ing.unitCost}" oninput="updateFormTotal()"></td><td><input class="form-total" readonly style="width:100%;padding:6px;background:#f1f5f9;" value="${ing.totalCost}"></td><td><button class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();updateFormTotal()"><i class="fas fa-trash"></i></button></td></tr>`);
    });
    if(!f.ingredients || f.ingredients.length === 0) addFormRow();
    updateFormTotal();
    const modal = document.getElementById('formulationModal');
    modal.classList.remove('hidden');
    modal.querySelectorAll('input, select').forEach(el => el.disabled = isView);
    const subBtn = document.getElementById('formulationForm').querySelector('button[type="submit"]');
    if(subBtn) subBtn.style.display = isView ? 'none' : 'inline-block';
}
window.viewFormulation = (idx) => { const f = getFormList()[idx]; if(f) { window._editIdx = idx; populateForm(f, true); } };
window.editFormulation = (idx) => { const f = getFormList()[idx]; if(f) { window._editIdx = idx; populateForm(f, false); } };
window.deleteFormulation = (idx) => { if(confirm('Delete formulation?')) { const list = getFormList(); list.splice(idx, 1); saveFormList(list); showToast('Deleted','success'); loadFormulations(); } };
document.getElementById('addFormulationBtn')?.addEventListener('click', () => {
    window._editIdx = null;
    document.getElementById('formulationForm').reset(); document.getElementById('formulationTableBody').innerHTML = '';
    document.getElementById('formDate').value = new Date().toISOString().split('T')[0];
    document.getElementById('formulationModal').classList.remove('hidden'); addFormRow(); updateFormTotal();
});
document.getElementById('addFormRowBtn')?.addEventListener('click', addFormRow);
document.getElementById('formulationForm')?.addEventListener('submit', e => {
    e.preventDefault(); updateFormTotal();
    const list = getFormList();
    const ingredients = [];
    document.querySelectorAll('#formulationTableBody tr').forEach(tr => {
        const inputs = tr.querySelectorAll('input');
        ingredients.push({ name:inputs[0].value, code:inputs[1].value, supplier:inputs[2].value, qty:inputs[3].value, batch:inputs[4].value, unitCost:inputs[5].value, totalCost:inputs[6].value });
    });
    const f = { id: window._editIdx !== null ? list[window._editIdx].id : Date.now(), name: document.getElementById('formProductName').value, client: document.getElementById('formClient').value, date: document.getElementById('formDate').value, status: document.getElementById('formStatus').value, utilities: document.getElementById('formUtilities').value, packaging: document.getElementById('formPackaging').value, labor: document.getElementById('formLabor').value, grandTotal: parseFloat(document.getElementById('footerGrandTotal').textContent)||0, ingredients };
    if(window._editIdx !== null) list[window._editIdx] = f; else list.push(f);
    saveFormList(list); showToast('Saved','success'); document.getElementById('formulationModal').classList.add('hidden'); loadFormulations();
});

// ✅ PURCHASE REQUESTS
window.loadPRs = async () => {
    console.log("🛒 Loading PRs...");
    try {
        const prs = await apiCall(`/api/purchase-requests?pos=${encodeURIComponent(currentUser.position)}&user=${encodeURIComponent(currentUser.name)}`, {}, 'GET');
        console.log("✅ PRs loaded:", prs.length);
        const tb = document.getElementById('prBody'); if(!tb) return;
        const isPurch = currentUser.position === 'Purchasing Dept';
        tb.innerHTML = prs.length ? prs.map(p => {
            let actions = '';
            if(isPurch && p.status==='Pending') actions = `<button class="btn btn-success btn-sm" onclick="updatePR(${p.id},'Accepted')">Accept</button> <button class="btn btn-danger btn-sm" onclick="updatePR(${p.id},'Declined')">Decline</button>`;
            else if(isPurch && p.status==='Accepted') actions = `<button class="btn btn-info btn-sm" onclick="updatePR(${p.id},'Delivered')">Mark Arrived</button>`;
            return `<tr><td>PR-${p.series_no}</td><td>${p.date_requested}</td><td>${p.items}</td><td style="text-align:center">${p.qty_unit}</td><td>${p.purpose}</td><td><span class="badge badge-${p.status==='Accepted'?'success':p.status==='Delivered'?'info':'warning'}">${p.status}</span></td><td>${actions}</td></tr>`;
        }).join('') : '<tr><td colspan="7" style="text-align:center;padding:20px;color:#888">No requests found</td></tr>';
    } catch(e) { showToast('Failed to load PRs', 'error'); }
};
document.getElementById('addPRBtn')?.addEventListener('click', () => { document.getElementById('prDateReq').value = new Date().toISOString().split('T')[0]; document.getElementById('prModal').classList.remove('hidden'); });
document.getElementById('prForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    try { await apiCall('/api/purchase-request', { requested_by: currentUser.name, department: document.getElementById('prDept').value, date_requested: document.getElementById('prDateReq').value, items: document.getElementById('prItems').value, qty_unit: document.getElementById('prQty').value, purpose: document.getElementById('prPurpose').value }); showToast('Submitted!', 'success'); document.getElementById('prModal').classList.add('hidden'); e.target.reset(); loadPRs(); } catch(e) { showToast('Failed', 'error'); }
});
window.updatePR = async (id, status) => {
    try { await apiCall(`/api/purchase-request/${id}/status`, { status, date_received: status==='Delivered'?new Date().toISOString().split('T')[0]:null, userPosition: currentUser.position }, 'PUT'); showToast(`Updated to ${status}`, 'success'); loadPRs(); } catch(e) { showToast('Failed', 'error'); }
};

// ✅ FLOATING CHAT (Fixed emoji & sender display)
function initMessengerChat() {
    console.log("💬 Initializing Chat...");
    const fab = document.getElementById('messenger-fab');
    const chat = document.getElementById('messenger-chat');
    const closeBtn = document.getElementById('m-close');
    const body = document.getElementById('m-msgs');
    const input = document.getElementById('m-input');
    const sendBtn = document.getElementById('m-send');
    const badge = document.getElementById('m-badge');

    if (!currentUser || !fab || !chat || !input || !sendBtn || !body) return;

    fab.style.display = 'flex';
    let lastCount = 0;

    const toggleChat = () => {
        const isOpen = chat.style.display === 'flex';
        chat.style.display = isOpen ? 'none' : 'flex';
        fab.style.display = isOpen ? 'flex' : 'none';
        if (!isOpen) { badge.style.display = 'none'; loadMessages(); setTimeout(() => input.focus(), 100); }
    };

    fab.onclick = toggleChat;
    if(closeBtn) closeBtn.onclick = toggleChat;

    const sendMessage = async () => {
        const txt = input.value.trim(); if (!txt) return;
        try {
            await apiCall('/api/chat/send', { organization: currentUser.organization, sender_name: currentUser.name, sender_dept: currentUser.position, message: txt });
            input.value = ''; loadMessages();
        } catch (err) { showToast('Failed to send', 'error'); }
    };
    sendBtn.onclick = sendMessage;
    input.onkeypress = (e) => { if(e.key === 'Enter') sendMessage(); };

    const loadMessages = async () => {
        try {
            const res = await fetch(`/api/chat/receive?org=${encodeURIComponent(currentUser.organization)}`);
            if (!res.ok) return;
            const msgs = await res.json();
            if (!Array.isArray(msgs)) return;

            if (chat.style.display !== 'flex' && msgs.length > lastCount) {
                badge.textContent = (msgs.length - lastCount) > 99 ? '99+' : (msgs.length - lastCount);
                badge.style.display = 'flex';
            }
            lastCount = msgs.length;

            // ✅ Display sender info
            body.innerHTML = msgs.map(m => {
                const isMe = m.sender_name === currentUser.name;
                let reactions = [];
                try { reactions = typeof m.reactions === 'string' ? JSON.parse(m.reactions) : (m.reactions || []); } catch(e){}
                const reactHtml = reactions.length ? `<div class="msg-reactions">${reactions.map(r => `<span>${r}</span>`).join('')}</div>` : '';
                return `
                <div class="msg-row ${isMe ? 'me' : 'them'}">
                    ${!isMe ? `<div class="msg-sender" style="font-size:11px;color:#666;margin-bottom:2px;"><strong>${m.sender_name}</strong> • ${m.sender_dept}</div>` : ''}
                    ${isMe ? `<button class="msg-delete" onclick="window.deleteMsg(${m.id})">✕</button>` : ''}
                    <div class="msg-bubble" onclick="window.showReactionPicker(${m.id}, this)">${m.message}</div>
                    ${reactHtml}
                </div>`;
            }).join('');
            body.scrollTop = body.scrollHeight;
        } catch (err) { console.warn("Chat load error", err); }
    };

    window.loadMessages = loadMessages;
    window.deleteMsg = async (id) => { if(confirm('Delete?')) { try { await fetch(`/api/chat/${id}`, { method: 'DELETE' }); loadMessages(); } catch(e){} } };
    window.showReactionPicker = (id, el) => {
        document.querySelectorAll('.reaction-picker').forEach(p => p.remove());
        const picker = document.createElement('div'); picker.className = 'reaction-picker';
        picker.innerHTML = '👍❤️😂😮😢'.split('').map(e => `<span onclick="window.addReaction(${id},'${e}')">${e}</span>`).join('');
        el.appendChild(picker);
        setTimeout(() => document.addEventListener('click', () => picker.remove(), {once:true}), 10);
    };
    window.addReaction = async (id, emoji) => { try { await fetch(`/api/chat/${id}/react`, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({emoji, userId: currentUser.name}) }); loadMessages(); } catch(e){} };

    if (chatInterval) clearInterval(chatInterval);
    chatInterval = setInterval(loadMessages, 2000);
    loadMessages();
}
