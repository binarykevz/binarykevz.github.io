require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');

if (!global.otpStore) global.otpStore = {};

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(require('cors')({ origin: '*' }));
app.use(require('helmet')({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(require('compression')());

const PUBLIC_DIR = path.resolve(__dirname, 'public');
app.use(express.static(PUBLIC_DIR, { maxAge: '30d' }));

// ✅ FIXED: Added charset for proper emoji support
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'formulab_db',
  charset: 'utf8mb4',
  waitForConnections: true, connectionLimit: 10, queueLimit: 0
});

const TG_TOKEN = process.env.TG_TOKEN, TG_CHAT_ID = process.env.TG_CHAT_ID;
const sendTelegram = async (text) => {
  if (!TG_TOKEN || !TG_CHAT_ID) return;
  fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: TG_CHAT_ID, text, parse_mode: 'Markdown' })
  }).catch(console.error);
};

(async () => {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS accounts (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) UNIQUE NOT NULL, username VARCHAR(100) NOT NULL, organization VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, position VARCHAR(100) NOT NULL, password VARCHAR(255), device TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`);
    await pool.query(`CREATE TABLE IF NOT EXISTS materials (id INT AUTO_INCREMENT PRIMARY KEY, organization VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, category VARCHAR(100), unit VARCHAR(50), price DECIMAL(10,2) DEFAULT 0, stock DECIMAL(10,2) DEFAULT 0, min_stock DECIMAL(10,2) DEFAULT 10, supplier VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`);
    await pool.query(`CREATE TABLE IF NOT EXISTS purchase_requests (id INT AUTO_INCREMENT PRIMARY KEY, requested_by VARCHAR(255), department VARCHAR(100), date_requested DATE, items TEXT, qty_unit VARCHAR(100), purpose TEXT, status ENUM('Pending','Approved','Accepted','Declined','Delivered') DEFAULT 'Pending', series_no VARCHAR(10), date_received DATE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`);
    
    await pool.query(`
      CREATE TABLE IF NOT EXISTS chats (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        organization VARCHAR(255) NOT NULL, 
        sender_name VARCHAR(255), 
        sender_dept VARCHAR(100), 
        message TEXT NOT NULL, 
        reactions TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
        INDEX idx_org (organization)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    
    try {
        const [cols] = await pool.query(`SHOW COLUMNS FROM chats LIKE 'reactions'`);
        if (cols.length === 0) {
            await pool.query(`ALTER TABLE chats ADD COLUMN reactions TEXT DEFAULT NULL`);
            console.log('✅ Added reactions column');
        }
    } catch(e) { console.error('Column check error:', e.message); }
    
    console.log('✅ MySQL Tables Ready');
  } catch (e) { console.error('❌ MySQL Init:', e.message); }
})();

if (!process.env.NODE_APP_INSTANCE || process.env.NODE_APP_INSTANCE === '0') {
  let lastId = 0;
  setInterval(async () => {
    if (!TG_TOKEN) return;
    try {
      const res = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/getUpdates?offset=${lastId + 1}`);
      const json = await res.json();
      if (json.ok && json.result?.length > 0) {
        for (const u of json.result) {
          lastId = Math.max(lastId, u.update_id);
          const t = u.message?.text?.trim(); const em = t?.match(/[^\s@]+@[^\s@]+\.[^\s@]+/)?.[0]?.toLowerCase();
          if (t?.startsWith('/delete') && em) { await pool.query('DELETE FROM accounts WHERE email = ?', [em]); await sendTelegram(`✅ Deleted: ${em}`); }
        }
      }
    } catch {}
  }, 1000);
}

app.post('/api/register', async (req, res) => { 
  try { 
    const { email, username, organization, name, position, password } = req.body; 
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' }); 
    await pool.query('INSERT INTO accounts (email, username, organization, name, position, password, device) VALUES (?,?,?,?,?,?,?)', [email, username, organization, name, position, password, '{}']);
    await sendTelegram(`💠 **New Account**\n👤 ${name}\n📧 ${email}`);
    res.json({ success: true }); 
  } catch (e) { 
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email/Username exists' });
    res.status(500).json({ error: 'Registration failed' }); 
  } 
});

app.post('/api/login', async (req, res) => { 
  try { 
    const [r] = await pool.query('SELECT * FROM accounts WHERE LOWER(email)=? OR LOWER(username)=?', [req.body.emailOrUser.toLowerCase(), req.body.emailOrUser.toLowerCase()]); 
    if (!r.length || r[0].password !== req.body.password) return res.status(401).json({ error: 'Invalid credentials' }); 
    res.json({ success: true, user: r[0] }); 
  } catch (e) { res.status(500).json({ error: e.message }); } 
});

app.post('/api/forgot-password', async (req, res) => { 
  try {
    const { email } = req.body; if (!email) return res.status(400).json({ error: 'Email required' });
    const [r] = await pool.query('SELECT name FROM accounts WHERE email=?', [email.toLowerCase()]);
    if (!r.length) return res.status(404).json({ error: 'Not found' });
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    global.otpStore[email] = { code: otp, expires: Date.now() + 600000 };
    res.json({ success: true, otp }); 
  } catch(e){ res.status(500).json({error:e.message}); } 
});

app.post('/api/verify-otp', async (req, res) => { 
  try { 
    const s = global.otpStore?.[req.body.email]; 
    if(!s || s.code!==req.body.otp || Date.now()>s.expires) return res.status(400).json({error:'Invalid OTP'}); 
    await pool.query('UPDATE accounts SET password=? WHERE email=?', [req.body.newPassword, req.body.email]); 
    delete global.otpStore[req.body.email]; 
    res.json({success:true}); 
  } catch(e){res.status(500).json({error:e.message});} 
});

app.get('/api/materials', async (req, res) => { try { const [rows] = await pool.query('SELECT * FROM materials WHERE organization=?', [req.query.org]); res.json(rows); } catch(e){res.status(500).json({error:e.message});} });
app.post('/api/materials', async (req, res) => { try { const [r] = await pool.query('INSERT INTO materials SET ?', req.body); res.json({success:true, id:r.insertId}); } catch(e){res.status(500).json({error:e.message});} });
app.put('/api/materials/:id', async (req, res) => { try { await pool.query('UPDATE materials SET ? WHERE id=?', [req.body, req.params.id]); res.json({success:true}); } catch(e){res.status(500).json({error:e.message});} });
app.delete('/api/materials/:id', async (req, res) => { try { await pool.query('DELETE FROM materials WHERE id=?', [req.params.id]); res.json({success:true}); } catch(e){res.status(500).json({error:e.message});} });

app.get('/api/purchase-requests', async (req, res) => { try { const isP = req.query.pos==='Purchasing Dept'; const [rows] = await pool.query(isP ? 'SELECT * FROM purchase_requests ORDER BY created_at DESC' : 'SELECT * FROM purchase_requests WHERE requested_by=?', [req.query.user]); res.json(rows); } catch(e){res.status(500).json({error:e.message});} });
app.post('/api/purchase-request', async (req, res) => { try { const [r] = await pool.query('SELECT COUNT(*) c FROM purchase_requests'); await pool.query('INSERT INTO purchase_requests SET ?', {...req.body, series_no: String(r[0].c+1).padStart(5,'0')}); res.json({success:true}); } catch(e){res.status(500).json({error:e.message});} });
app.put('/api/purchase-request/:id/status', async (req, res) => {
  try {
    const { status, date_received, userPosition } = req.body;
    if (userPosition !== 'Purchasing Dept') return res.status(403).json({ error: 'Access Denied' });
    await pool.query('UPDATE purchase_requests SET status=?, date_received=? WHERE id=?', [status, date_received||null, req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ✅ CHAT ROUTES (Fixed emoji encoding)
app.post('/api/chat/send', async (req, res) => {
  try {
    const { organization, sender_name, sender_dept, message } = req.body;
    if (!organization || !message || !sender_name) return res.status(400).json({ error: 'Missing fields' });
    await pool.query('INSERT INTO chats (organization, sender_name, sender_dept, message, reactions) VALUES (?, ?, ?, ?, ?)', [organization, sender_name, sender_dept, message, '[]']);
    res.json({ success: true });
  } catch (e) { console.error('❌ Chat Send Error:', e.message); res.status(500).json({ error: e.message }); }
});

app.get('/api/chat/receive', async (req, res) => {
  try {
    const org = req.query.org;
    if (!org) return res.status(400).json({ error: 'Org required' });
    const [rows] = await pool.query('SELECT id, sender_name, sender_dept, message, reactions, created_at FROM chats WHERE organization = ? ORDER BY created_at ASC LIMIT 100', [org]);
    const messages = rows.map(row => {
      let reactions = [];
      try { reactions = typeof row.reactions === 'string' ? JSON.parse(row.reactions) : (row.reactions || []); } catch(e) {}
      return { id: row.id, sender_name: row.sender_name, sender_dept: row.sender_dept, message: row.message, reactions };
    });
    res.json(messages);
  } catch (e) { console.error('❌ Chat Receive Error:', e.message); res.status(500).json({ error: e.message }); }
});

app.delete('/api/chat/:id', async (req, res) => {
  try { await pool.query('DELETE FROM chats WHERE id = ?', [req.params.id]); res.json({ success: true }); } 
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/chat/:id/react', async (req, res) => {
  try {
    const { emoji } = req.body;
    const [msgs] = await pool.query('SELECT reactions FROM chats WHERE id = ?', [req.params.id]);
    if (!msgs.length) return res.status(404).json({ error: 'Not found' });
    let reactions = [];
    try { reactions = typeof msgs[0].reactions === 'string' ? JSON.parse(msgs[0].reactions) : (msgs[0].reactions || []); } catch(e) {}
    const idx = reactions.indexOf(emoji);
    if (idx > -1) reactions.splice(idx, 1); else reactions.push(emoji);
    await pool.query('UPDATE chats SET reactions = ? WHERE id = ?', [JSON.stringify(reactions), req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`🌐 Running :${PORT} | 💾 MySQL Active`));
